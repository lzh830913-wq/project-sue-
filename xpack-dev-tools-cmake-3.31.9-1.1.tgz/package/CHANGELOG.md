# Change & release log

Entries in this file are in reverse chronological order.

## 2025-10-04

* v3.31.9-1.1 published on npmjs.com
* 67b1c47 package.json: update URLs for 3.31.9-1.1 release
* 980e2d2 website: blog post release 3.31.9-1.1 published
* b26c5bb CHANGELOG update
* v3.31.9-1 released
* 95d62b8 website: update actions durations
* d6eba47 workflows update
* 4203c0c workflows update
* 7138a86 workflows update
* 570998b workflow add npm
* e790ad3 workflow try without homebrew

## 2025-10-03

* a45ac7c website: update folder hierarchies
* 2be1eaf website: update development durations
* 78ae3c9 versioning.sh update link
* 44e5f9b prepare v3.31.9-1
* v3.31.9-1 prepared
* 10cff99 website: regenerate commons
* 144fc8d 3.30.9-1.1
* 42dbeea CHANGELOG: publish npm v3.30.9-1.1
* v3.30.9-1.1 published on npmjs.com
* ca4d83c package.json: update URLs for 3.30.9-1.1 release
* cfece8f website update
* ca26fb4 website: blog post release 3.30.9-1.1 published
* 5cc98f3 CHANGELOG update
* v3.30.9-1 released
* f33f583 website: update actions durations
* 5f06a05 website update
* e34c0b5 prepare v3.30.9-1
* b3603d8 website: re-generate commons
* 22cbcbd re-generate top commons to bump deps

## 2025-04-09

* 8179381 test-sourceforge*: on every Saturday

## 2025-04-06

* 3f7d45c test-sourceforge-downloads.yml update

## 2025-04-05

* 0317405 test-sourceforge-downloads.yml update
* 11781b7 test-sourceforge-downloads.yml update
* 79e4b2c test-sourceforge-downloads.yml update
* ba474e4 test-sourceforge-downloads.yml update
* b5ce838 test-sourceforge-downloads.yml update
* dc9411b add test-sourceforge-downloads.yml

## 2025-03-23

* 554593f update /licenses/MIT
* c0f99ed website: re-generate commons
* f6b8ed7 re-generate commons
* 36eee4f website package.json shareOnTwitter update
* 3279e36 website package.json author update
* 94d2f31 website generate-website-commons update

## 2025-02-24

* c5da434 website: re-generate descriptive & permalink names
* 30675b5 re-generate descriptive & permalink names

## 2025-02-23

* fa58d4b website: re-generate commons

## 2025-02-18

* 70309a7 package.json: bump minimumXpmRequired 0.20.5
* 7d0d135 package.json: bump xpm 0.20.5

## 2025-02-17

* 01b7d02 re-generate workflows without self-hosted
* 066017a re-generate workflows

## 2025-02-14

* e849ff9 re-generate commons
* d465f24 re-generate commons

## 2025-02-13

* d938608 versioning.sh: ncurses with --hack-links
* 8d8ef87 re-generate commons

## 2025-02-07

* 827a345 website: re-generate commons

## 2025-02-05

* fc51efc website: fix post permalink
* b502222 website: re-generate commons
* 3bfdf21 website: fix post permalink

## 2025-02-04

* aedbdee website: re-generate commons
* a8081c9 3.30.7-1.1
* a883554 package.json: .pre
* 4a23cfd CHANGELOG: publish npm v3.30.7-1.1

## 2025-02-04

* v3.30.7-1.1 published on npmjs.com
* 8b76925 package.json: update urls for 3.30.7-1.1 release
* 1f0cd74 website: blog post release 3.30.7-1 published
* 9b2d953 build-assets/package.json: update generate-website-blog-post
* a4dfba6 CHANGELOG update
* 808252e website: re-generate commons
* 4fd7d8b build-assets/package-lock.json update
* 35a8c72 website: re-generate common
* b858884 website: update folder hierarchies
* 7d4ee9a cmake.sh: CMAKE_USE_SYSTEM_CURL=OFF
* d2684bf prepare v3.30.7-1

## 2025-02-03

* f9374a5 build-assets: bump deps
* b6afa52 website: re-generate commons
* 0eba00c website: re-generate commons

## 2025-02-02

* dc2df97 website: re-generate commons

## 2025-01-31

* a7593a2 website: updates and final common rework

## 2025-01-30

* 18ab18b website: rework getting-started
* 5912a34 website: more rework with commons

## 2025-01-29

* e3fc712 website: more rework with commons

## 2025-01-27

* 487c8ad website: cosmetise imports

## 2025-01-26

* 4844869 website: rework with _project

## 2025-01-23

* 8d37d6a website: re-generate commons

## 2025-01-22

* 9b42104 website: re-generate commons

## 2025-01-21

* 474a127 build-assets: cleanup actions
* 33af719 website: re-generate commons
* f1b4297 website: re-generate commons
* 82cd00e website: re-generate commons

## 2025-01-20

* 4150f6c re-generate commons
* 7cc154f website: re-generate commons

## 2025-01-19

* 773d5d7 website: remove unused customField.js
* 021e886 build-assets: move customFields to websiteConfig
* 1d0da7b website: re-generate commons

## 2025-01-17

* a7bb9fc website: re-generate commons
* 1d04031 re-generate commons
* 79b9a7e website: re-generate commons

## 2025-01-16

* 597795d website: re-generate commons
* cb0e545 re-generate commons

## 2025-01-15

* 782b6a8 re-generate commons

## 2025-01-14

* 5596620 re-generate commons
* ce33fb6 re-generate commons

## 2025-01-13

* 5663a10 copyright updates
* 372f26f copyright updates

## 2025-01-10

* 892aea6 website: updates
* af9ab2f website: updates
* c604e81 website: updates

## 2025-01-09

* ea2be16 build-assets/package.json: bump deps
* 8fec45d website: updates

## 2025-01-02

* 7464d0e website: re-generate commons
* 89a5839 website: re-generate commons
* 1156934 3.29.9-1.1
* 550f388 CHANGELOG: publish npm v3.29.9-1.1

## 2025-01-02

## 2025-01-02

* 7464d0e website: re-generate commons
* 89a5839 website: re-generate commons
* 1156934 3.29.9-1.1
* 550f388 CHANGELOG: publish npm v3.29.9-1.1
* 5e65188 package.json: update urls for 3.29.9-1.1 release
* 3862729 website: blog post release 3.29.9-1 published
* 79d8946 CHANGELOG update
* v3.29.9-1 released
* fa1ab3a website: re-generate commons
* c7ac66d re-generate workflows
* f489405 website: update actions durations
* d66e25b build-assets/package.json: bump deps
* c0257c6 website updates
* 2f496fe prepare v3.29.9-1
* 07b8839 website re-generate commons
* 11be840 re-generate commons

## 2024-12-31

* 2c5cae6 website: updates

## 2024-12-30

* 5a25e68 package.json: bump deps
* d60e6fc website: updates

## 2024-12-24

* bd010b8 website: updates
* fab7ad1 website: updates

## 2024-12-22

* b348f72 website: update redirects
* 786aba6 website: updates
* 8a605ff website: add _xpack.github.io

## 2024-12-20

* 61b0940 website: updates
* fbb68d4 website: updates
* da2bcd4 website: updates

## 2024-12-11

* 06d75de website: updates
* 0109025 website/blog updates
* c0ea748 website/blog/_templates/blog-post-release*

## 2024-12-04

* 2448717 website: updates
* 949ad84 build-assets/package.json: bump deps

## 2024-10-15

* b826266 website: updates
* 04e739a website: updates

## 2024-10-14

* 7dc9d37 website: updates

## 2024-10-13

* f275841 website: updates
* 287450f website: updates
* f4bc72c website: updates

## 2024-10-11

* e1f1be3 website: updates
* dc39775 website/blog/_templates/blog-post-release*
* d03df08 website/blog/_templates/blog-post-release*

## 2024-10-10

* 63dd6f3 website: updates
* ce1ef14 website: updates

## 2024-10-09

* a300fa8 website move blog post templates
* df40b63 website: updates
* 9b4c064 website: updates

## 2024-10-07

* 825c1cb website: updates
* 53398aa website: updates

## 2024-10-06

* 44e051e website: updates
* a3e5192 website: updates
* fc3ca43 re-generate workflows

## 2024-10-04

* 9f96f43 website: updates
* a774ae0 templates/body-blog update

## 2024-09-18

* a8046fb website: updates
* 2e5282b website update
* 8d018fa build-assets/package.json update customFields
* 920d510 build-assets/templates updates

## 2024-09-13

## 2024-09-13

* 31fdf2c website: add content
* 8b18f15 3.28.6-1.1
* 12f5152 CHANGELOG: publish npm v3.28.6-1.1
* 5b1316c package.json: update urls for 3.28.6-1.1 release
* 27e9178 build-assets/templates update
* 4e4d533 CHANGELOG update
* e73d6d7 re-generate workflows
* 06b2910 CHANGELOG update
* f80ccb0 re-generate workflows
* 7e7dc55 run.sh: mkdir SOURCE
* 95347b1 build-assets/package* update
* b32a22b run.sh: use download_and_extract
* 376a526 re-generate workflows
* 322c0cc prepare v3.28.6-1
* 3e70159 build-assets/package.json: bump deps
* bacf9da re-generate workflows

## 2024-09-12

* 523a459 update scripts copyright notices

## 2024-08-17

* de256ca website remove preliminary
* f797f3f build-assets/package.json: updates
* 8cff0a5 templates/body-blog update
* 2acc146 templates/body-github: update
* 40f49ed re-generate workflows

## 2024-08-16

* e917a13 templates/body-github: update

## 2024-08-14

* 9f8541b build-assets/package.json: updates

## 2024-08-09

* 883c8fb READMEs update
* 33254e2 package.json: git+https
* 95afa3d build-assets/package.json: updates
* 8b2b657 templates/body-blog update

## 2024-08-07

* da31cb5 build-assets/package.json: updates
* 9ad48b7 build-assets/package.json: updates
* dbd15df website: preliminary content
* 781cc14 re-generate workflows
* 587e24d move to build-assets

## 2024-08-06

* b66cd9f package.json: bump deps

## 2024-08-04

* b0dc4ec package.json: bump deps
* 03f9751 package.json: update generate-workflows
* 75bdfdd templates/jekyll update
* 14adf80 cmake.sh: use is_development
* 434eef0 READMEs update
* 98171c5 package.json: add actions, bump deps

## 2024-07-27

* 7370f32 package.json: add actions, bump deps
* fa8c5db templates/jekyll update

## 2024-07-23

* 567185c READMEs update
* e0959c7 re-generate scripts
* 8050096 body-jekyll update
* 9302bf3 re-generate workflows
* 8891588 package.json: rework generate workflows
* 4fad3ba package.json: loglevel info
* 608af34 package.json: bump deps

## 2024-06-18

* a4c97ee re-generate .npmignore
* 2d6d666 package-lock.json: update
* 01da461 re-generate test.sh
* 622b57c re-generate workflows
* 7b6ee25 package.json: rework generate workflows
* a737fd6 scripts/tests/update.sh: simplify
* d6d5042 READMEs update

## 2024-06-17

* c83fbb3 package.json: bump deps
* eac24f6 application.sh: update

## 2024-05-28

* 69dc007 cmake.sh: fix log dates

## 2024-05-23

* 6789f2c package.json: clang 16.0.6-1.1

## 2024-05-18

* ceb9cce rework git_clone calls
* 0e8330a READMEs update
* f5693ae package.json: XBB_ENVIRONMENT_SKIP_CHECKS

## 2024-05-16

* 7bcc584 READMEs update
* 2dce47a versioning.sh: ncurses with --disable-lib-suffixes

## 2024-05-14

* 887f4c1 versioning.sh: ncurses with --disable-lib-suffixes

## 2024-05-09

* cc82773 use is_develop and with_strip

## 2024-05-07

* 062cc47 versioning.sh: remove DISABLE_WIDEC

## 2024-05-03

* b359271 package.json: add bison to deps

## 2024-05-02

* a73f68c package.json: add m4 to deps
* 2f2a2b3 package.json: clang 17.0.6-1.1
* d8a76b2 README update
* 55f1ef8 cmake.sh: conditional -DCMAKE_OSX_DEPLOYMENT_TARGET

## 2024-04-14

* 7b90c05 versioning.sh: avoid xz 5.6

## 2024-04-04

* 038196d package.json: clang 17

## 2024-04-02

* a353b62 3.27.9-1.2
* a88a2cc prepare 3.27.9-1.2
* 263b2ac 3.27.9-1.1
* e952a68 CHANGELOG: publish npm v3.27.9-1.1
* 82c39f3 package.json: update urls for 3.27.9-1.1 release
* 262f3ca README update
* 23ec7d8 body-jekyll update
* 7b8acb3 CHANGELOG update
* 4bea4df README update
* b2ec90f re-generate workflows
* 98a8e63 prepare v3.27.9-1
* 63cec33 README update
* 581feb0 package.json: bump deps
* aec6398 versioning.sh: bump deps

## 2024-03-23

* 5c10ede README update
* 85fa9fd README update
* 23a648f README update
* 17a6028 README update
* 403b1f2 package-lock.json update
* 304e22a versioning.sh: bump openssl 3.2.1

## 2024-03-22

* 92ee2cf package.json: xpm-version 0.18.0

## 2024-03-08

* 3a514e6 package.json: xpm-version 0.18.0

## 2024-03-07

* 19dc56c package.json: xpm-version 0.18.0
* b7e5f94 package.json: bump deps

## 2024-03-06

* 05246de body-jekyll update
* 2b41545 package.json: bump deps

## 2024-02-14

* b123d7b update 3.27.9.git.patch

## 2024-02-12

* e10e41d update 3.27.9 patch

## 2024-02-09

* d20e895 versioning.sh: add 3.27.*
* bf7c23e add 3.27.9 patch
* d03aa95 prepare v3.27.9-1

## 2024-02-07

* b9560a8 READMEs update
* df6eaca package.json: bump deps

## 2023-12-03

* bb44817 package.json: bump deps
* 141711b re-generate workflows

## 2023-11-12

* 71b094e package.json: bump deps

## 2023-09-25

* 13068be body-jekyll update

## 2023-09-20

* 0d5151c package.json: bump deps

## 2023-09-16

* b8d1c76 package.json: add linux32
* 81359fa body-jekyll update

## 2023-09-11

* 76ddaf1 package.json: bump deps

## 2023-09-08

* 300e77f package.json: bump deps
* a3134d9 package-lock.json update

## 2023-09-06

* 7be3347 package.json: bump deps
* e4ee7c0 READMEs update
* 11bb8a7 body-jekyll update

## 2023-09-05

* 203c4ba re-generate workflows
* cdc58a1 READMEs update
* 4a59810 package.json: bump deps

## 2023-09-03

* d199936 package.json: bump deps

## 2023-08-28

* de8a80a READMEs update

## 2023-08-25

* 41a1148 3.26.5-1.1
* 0749f0f CHANGELOG: publish npm v3.26.5-1.1
* 20d9267 README update
* e317e71 package.json: update urls for 3.26.5-1.1 release
* 81fef80 templates/jekyll update
* 5338d29 CHANGELOG update
* a80e0fb README update
* 42338fb README update
* 6330e40 update dot.*ignore
* 0c0cf6c versioning.sh: add support for 3.26.5
* 9b0d7b8 add cmake-3.26.5.git.patch
* f874749 re-generate workflows
* cd05b6a prepare v3.26.5-1
* 6d69d1a package.json: rm xpack-dev-tools-build/*
* 4cd98f5 package.json: bump deps

## 2023-08-21

* e4eecfb READMEs update
* c17981a package.json: bump deps

## 2023-08-19

* 5433ff5 READMEs update
* 059c7cb package.json: bump deps

## 2023-08-15

* f34fedc re-generate workflows
* de5145d README-MAINTAINER rename xbbla
* b0362d1 package.json: rename xbbla
* cee8168 package.json: bump deps
* a470e50 READMEs update
* 9aa2ecd README update
* fba9859 package.json: bump deps

## 2023-08-14

* 04c7c66 dot.ignore updates
* c8f4d62 re-generate workflows
* f51e42c 3.25.3-2.1.pre

## 2023-08-05

* 23e0dc4 READMEs update

## 2023-08-04

* d6c8430 READMEs update
* f682b9a READMEs update
* d07e484 package.json: add build-develop-debug
* 2e8032b READMEs update

## 2023-08-03

* 61caf97 package.json: reorder build actions
* 7fd295c READMEs update
* c8cd03a package.json: bump deps

## 2023-07-28

* baca34c READMEs update
* 94ee622 package.json: bump deps
* f68faf8 package.json: liquidjs --context --template
* b707d74 READMEs update
* eef72aa package.json: bump deps

## 2023-07-27

* bb422ef package.json: revert to npm helper
* 33a1b4a package.json: temporarily use github:helper
* c8ebcef 3.25.3-1.1
* 30f1eca CHANGELOG: publish npm v3.25.3-1.1
* fcdf76e package.json: update urls for 3.25.3-1.1 release
* 91f481d README update
* 15d6661 templates/jekyll update
* bc41820 CHANGELOG update
* 7ed6ee0 README update
* 283f005 prepare v3.25.3-1
* 9efb6d7 package.json: bump helper 1.4.11
* v3.24.4-1.1 published on npmjs.com
* 37d1567 3.24.4-1.1
* 4936866 CHANGELOG: publish npm v3.24.4-1.1
* a0cfafe package.json: update urls for 3.24.4-1.1 release
* 4c716f0 /@xpack-dev-tools/xbb-helper/
* 1fcf76c re-generate workflows
* 3a98737 README update
* cba5b32 templates/jekyll update
* 69a27fa package.json: bump helper 1.4.10
* e853677 CHANGELOG update
* e2a496b re-generate workflows

## 2023-07-26

* 337a0bf re-generate workflows (depth: 3)
* bcfdd9a README update
* 0ac0507 prepare v3.24.4-1
* 8e9baca package.json: move scripts to actions
* bcfc850 package.json: update xpack-dev-tools path
* 5d40feb READMEs update xpack-dev-tools path
* d3814cb body-jekyll update
* 528a634 READMEs update

## 2023-07-17

* 1d425f2 package.json: bump deps

## 2023-03-31

* b8c9458 dependencies CMAKE=$(which cmake)

## 2023-03-25

* c20a3b3 READMEs update
* 5effb78 Merge branch 'xpack-develop' of https://github.com/xpack-dev-tools/cmake-xpack into xpack-develop
* c480589 READMEs update prerequisites
* c76a160 package.json: mkdir -pv cache

## 2023-02-22

* ccb1c68 READMEs update

## 2023-02-14

* a520c27 body-jekyll update

## 2023-02-10

* ba9cd55 Merge branch 'xpack-develop' of https://github.com/xpack-dev-tools/cmake-xpack into xpack-develop
* 07e3de4 package.json: update Work/xpacks
* a201acd READMEs update

## 2023-02-07

* 2bf642e READMEs update
* 8efd203 versioning.sh: update for https
* b6ed166 body-jekyll update

## 2023-01-28

* 3c1ce8d cmake.sh: MACOSX_DEPLOYMENT_TARGET
* c3b5bcc tests/run.sh: use versioning functions
* c10917d cmake.sh: use versioning functions
* d0b0cd7 versioning.sh: use versioning functions
* fcae9c2 README-MAINTAINER remove caffeinate xpm

## 2023-01-27

* 9041dfc package.json: reorder scripts

## 2023-01-24

* v3.23.5-1.1 published on npmjs.com
* 17de7de package.json: update urls for 3.23.5-1.1 release
* c218df3 README update
* 6de2d5b README update
* f5724e5 body-jekyll update
* d188a91 CHANGELOG update
* v3.23.5-1 released
* 69ec36f package.json: bump deps
* 2a691a9 README update
* 0118354 README updates
* 4adffef version 3.23.5-1
* c3e5cf1 add cmake-3.25.5.git.patch
* f41121e .vscode/settings.json: ignoreWords
* 9ec8da6 prepare v3.23.5-1
* 16a589a re-generate workflows
* 7d3437f package.json: bump deps

## 2023-01-22

* 0c53fd1 README update

## 2023-01-11

* 46d9258 cosmetize xbb_adjust_ldflags_rpath

## 2023-01-09

* 2a1db48 cmake.sh: cleanups
* 886fd0f package.json: bump deps
* ffdee53 package.json: loglevel info
* 6b9e8f3 versioning.sh: add comment before *_installed_bin

## 2023-01-02

* 219ec3a package.json: add gcc to windows deps

## 2023-01-01

* bb89135 package.json: pass xpm version & loglevel
* f4ecefd README update

## 2022-12-30

* 9cb7ae0 README-MAINTAINER: xpm run install
* 0958c39 package.json: bump deps
* 7a0a2f1 versioning.sh: regexp

## 2022-12-27

* 5d2b9c2 README update
* b4226e1 echo FUNCNAME[0]
* dd12d06 re-generate from templates
* 0ea91b2 cosmetics: move versions to the top

## 2022-12-26

* 7326668 README updates

## 2022-12-25

* 24622bd README update
* 4b76426 versioning.sh: remove explicit xbb_set_executables_install_path

## 2022-12-24

* ffacadf versioning.sh: explicit set_executables
* 1caca15 READMEs updates
* fb59558 .vscode/settings.json: ignoreWords
* 877387a CHANGELOG.md: use bullet list
* c88fc1a cmake.sh: update run_host_app_verbose
* 5d8378c package.json: updates
* a45b9f1 package.json: bump deps
* 765c0e5 versioning.sh: updates
* e01f8aa cmake.sh: updates
* e41fd0d cmake.sh: use XBB_HOST_* in tests
* 5aacedb re-generate from templates
* b0346fb rename functions

## 2022-12-12

* 34c2ce7 package.json: add caffeinate builds for macOS
* d43d280 versioning.sh: use XBB_REQUESTED_*

## 2022-11-18

* 2bef034 .vscode/settings.json: watcherExclude

## 2022-10-26

* 48e1a72 versioning.sh: build_application_versioned_components
* 52418b6 versioning.sh: remove sub-shell
* 778d6ba package.json: bump deps
* f4a5e7d cmake.sh: create XBB_STAMPS_FOLDER_PATH

## 2022-10-25

* 2e9c216 test.sh: source download.sh
* 37ac8c7 package.json: bump deps
* 417983b versioning.sh: remove 3.23 preview
* dfde2f9 application.sh: COMMON_DEPENDENCIES zlib
* a4fc9b3 versioning.sh: add build_zlib
* c2399fc package.json: bump deps
* 1756d05 re-generate workflows
* 66afd94 package.json: cleanup
* 479cc95 versioning.sh: build_openssl
* 8c23c93 Merge remote-tracking branch 'origin/xpack-develop' into xpack-develop
* b5c4884 package.json: deps
* 5a2c0ea README update

## 2022-10-24

* ec07642 cmake.sh: -lpthread
* 33cee42 package.json: remove apt-get
* 94015d3 versioning.sh: build_openssl
* 7e95ec1 cmake.sh: xbb_activate_cxx_rpath
* b5a64f1 cmake.sh: add links to arch & hb

## 2022-10-23

* 9b7addd package.json: apt-get install make
* 3508c51 package.json: bump deps
* 40b78b2 package.json: bump deps
* d5c0da5 READMEs cosmetics
* 218b9a3 cosmetics
* 7666f47 rename application.sh
* 6b3e53e versions.sh: remove build_coreutils
* 06855da package.json: add devDependency to realpath
* 95a589a package.json: reorder actions

## 2022-10-19

* v3.23.5-1 released
* 5fdab3c READMEs update
* f4c0cb7 .gitignore update
* 8176715 versioning.sh: XBB_COREUTILS_INSTALL_REALPATH_ONLY
* b563dfa READMEs updates
* 20a6ee2 body-jekyll: cosmetics
* 70e4fab cmake.sh: cosmetics
* acc51f8 update.sh: remove common installs
* 1aff168 build.sh & test.sh: use *_DEPENDENCIES
* e7d604a versioning.sh: temporarily add build_coreutils
* 5d73305 package.json: remove xbb-bootstrap

## 2022-10-17

* 296f331 READMEs updates
* 3d52d29 .vscode/settings.json: ignoreWords
* 67a93bc cmake.sh: -DCMAKE_OSX_DEPLOYMENT_TARGET
* 867a5db cmake.sh: -Wno-deprecated-declarations
* 81ef80a updates for xbb v4.0
* e953e04 remove submodule

## 2022-10-04

* 94b29d8 README update
* 86a5ad2 README-RELEASE update for bullet lists in CHANGELOG

## 2022-09-25

* 2128f56 README-RELEASE update

## 2022-09-17

* 3bae59e package.json: remove -ia32
* 7dd7155 README-BUILD update

## 2022-09-03

* f89b90d READMEs updates

## 2022-09-01

* v3.22.6-1.1 published on npmjs.com
* v3.22.6-1 released

## 2022-03-25

* v3.21.6-1.1 published on npmjs.com
* v3.21.6-1 released

## 2021-12-06

* v3.20.6-2 released

## 2021-11-20

* v3.20.6-2 prepared
* add support for Apple Silicon

## 2021-10-18

* v3.20.6-1.1 published on npmjs.com
* v3.20.6-1 released
* v3.20.6-1 prepared

## 2021-09-11

* update for the new build scripts

## 2021-05-19

* v3.19.8-1.1 published on npmjs.com
* v3.19.8-1 released

## 2021-03-17

* v3.19.2-2.1 published on npmjs.com
* v3.19.2-2 prepared

## 2021-03-16

* v3.18.6-1.1 published on npmjs.com
* v3.18.6-1 released
* add cmd.exe support

## 2021-01-06

* v3.19.2-1.1 published on npmjs.com
* v3.19.2-1 released

## 2020-12-15

* v3.19.1-1.1 published on npmjs.com
* v3.19.1-1 released

## 2020-12-09

* v3.18.5-1.1 published on npmjs.com
* v3.18.5-1 released

## 2020-09-29

* v3.18.3-1.1 published on npmjs.com
* v3.18.3-1 released

## 2020-07-22

* prepare v3.17.3-1
